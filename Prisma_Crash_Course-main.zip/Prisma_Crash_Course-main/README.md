# Prisma_Crash_Course

## To Setup project in your machine hit below command

`npm install`

### After this command create new file .env and paste .env.example file code to in this file

**After that**

Just change your password with my name and if you have different DB name then change it from **prismaDB**
